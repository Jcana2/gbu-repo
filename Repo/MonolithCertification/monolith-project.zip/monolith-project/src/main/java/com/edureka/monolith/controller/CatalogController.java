package com.edureka.monolith.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.edureka.monolith.entities.Catalog;
import com.edureka.monolith.repositories.CatalogRepository;

@RestController
public class CatalogController {

	@Autowired
	CatalogRepository catalogRepository;

	
	@GetMapping("/products")
	public List<Catalog> getCatalogs() {
		return catalogRepository.findAll();
	}
	
	@GetMapping("/products/{id}")
	public Catalog getCatalog(@PathVariable String id) {
		return catalogRepository.findById(Long.parseLong(id)).get();
	}
	
	@GetMapping("/products/add")
	public String addProduct() {
		catalogRepository.save(new Catalog("Pixel 6", "Google's newest smart phone.", 599.99));
		return "Product has been added!";
	}
	
}
