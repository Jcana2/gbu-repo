package com.edureka.monolith.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.authority.AuthorityUtils;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.edureka.monolith.repositories.AccountRepository;


@Service 
class AirlineService implements UserDetailsService {
	
	private final AccountRepository accountRepository;
	
	@Autowired
	public AirlineService(AccountRepository accountRepository) {
		this.accountRepository = accountRepository;
	}
	
	@Override public UserDetails loadUserByUsername(String userName) throws UsernameNotFoundException {
		return this.accountRepository.findByUserName(userName).map(u->new User(u.getUserName(), u.getPassword(),u.isActive(),u.isActive(),u.isActive(),u.isActive(),AuthorityUtils.createAuthorityList("ADMIN","USER"))).orElseThrow(()-> new UsernameNotFoundException("Could not find user"));
	}
}