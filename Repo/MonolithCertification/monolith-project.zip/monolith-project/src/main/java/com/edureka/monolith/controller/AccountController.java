package com.edureka.monolith.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.edureka.monolith.entities.Account;
import com.edureka.monolith.repositories.AccountRepository;

@RestController
public class AccountController {

	@Autowired
	AccountRepository accountRepository;

	
	@GetMapping("/users/login")
	public String login() {
		return "You have already logged in!";
	}
	
	@GetMapping("/users")
	public List<Account> getUsers() {
		return accountRepository.findAll();
	}
	
	@GetMapping("/users/{id}")
	public Account getUser(@PathVariable String id) {
		return accountRepository.findById(Long.parseLong(id)).get();
	}
	

	
}
