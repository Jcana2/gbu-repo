package com.edureka.monolith.entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class Ordering {

	@Id
	@GeneratedValue
	private long id;
	private String email;
	private String product;
	private int quantity;
	
	public Ordering() {
		super();
	}

	public Ordering(String email, String product, int quantity) {
		super();
		this.email = email;
		this.product = product;
		this.quantity = quantity;
	}

	public Ordering(long id, String email, String product, int quantity) {
		super();
		this.id = id;
		this.email = email;
		this.product = product;
		this.quantity = quantity;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getProduct() {
		return product;
	}

	public void setProduct(String product) {
		this.product = product;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	
	
}
