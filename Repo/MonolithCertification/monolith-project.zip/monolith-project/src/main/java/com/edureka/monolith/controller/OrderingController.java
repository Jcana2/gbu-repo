package com.edureka.monolith.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.edureka.monolith.entities.Account;
import com.edureka.monolith.entities.Catalog;
import com.edureka.monolith.entities.Ordering;
import com.edureka.monolith.repositories.CatalogRepository;
import com.edureka.monolith.repositories.OrderingRepository;

@RestController
public class OrderingController {

	@Autowired
	OrderingRepository orderingRepository;
	
	@GetMapping("/orders")
	public List<Ordering> getOrders() {
		return orderingRepository.findAll();
	}
	
	@GetMapping("/orders/{id}")
	public Ordering getCatalog(@PathVariable String id) {
		return orderingRepository.findById(Long.parseLong(id)).get();
	}
	
	@GetMapping("/orders/cancel/{id}")
	public String deleteOrder(@PathVariable String id) {
		orderingRepository.deleteById(Long.parseLong(id));
		
		return("Booking of ID:" + id + " has been deleted");
	}
	
}
