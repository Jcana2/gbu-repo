package com.edureka.monolith;

import java.util.stream.Stream;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import com.edureka.monolith.entities.Account;
import com.edureka.monolith.entities.Catalog;
import com.edureka.monolith.entities.Ordering;
import com.edureka.monolith.repositories.AccountRepository;
import com.edureka.monolith.repositories.CatalogRepository;
import com.edureka.monolith.repositories.OrderingRepository;

@SpringBootApplication
public class MonolithApplication {

	/**
	 * @author Jhoj Cana 2122891
	 * @param args
	 */
	
	public static void main(String[] args) {
		SpringApplication.run(MonolithApplication.class, args);
	}
	
	@Bean
	public CommandLineRunner commandLineRunner(AccountRepository repository) {
		return args -> Stream.of("edureka,{noop}edureka","username,{noop}password").map(u->u.split(",")).forEach(t->repository.save(new Account(t[0],t[1],true)));
	}
	
	@Bean
	public CommandLineRunner seedDatabase(CatalogRepository catalogRepository, OrderingRepository orderingRepository) {
		return args -> {
			catalogRepository.save(new Catalog("Macbook Pro", "Apple's latest laptop.", 1299.99));
			catalogRepository.save(new Catalog("Galaxy S21", "Samsung's newest flagship phone.", 899.99));
			catalogRepository.save(new Catalog("Apple Watch", "A smart wrist watch developed by Apple", 399.99));
			
			orderingRepository.save(new Ordering("paul@tcs.com", "Macbook Pro", 1));
			orderingRepository.save(new Ordering("Ethan@tcs.com", "Apple Watch", 2));
			orderingRepository.save(new Ordering("Alex@tcs.com", "Galaxy S21", 4));
			orderingRepository.save(new Ordering("Eric@tcs.com", "Macbook Pro", 2));
			
			
		};
	}

}
